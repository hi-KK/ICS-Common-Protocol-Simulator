﻿namespace Automatak.Simulator.DNP3.Components
{
    partial class ClassFieldControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkBoxClass0 = new System.Windows.Forms.CheckBox();
            this.checkBoxClass1 = new System.Windows.Forms.CheckBox();
            this.checkBoxClass2 = new System.Windows.Forms.CheckBox();
            this.checkBoxClass3 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // checkBoxClass0
            // 
            this.checkBoxClass0.AutoSize = true;
            this.checkBoxClass0.Location = new System.Drawing.Point(11, 13);
            this.checkBoxClass0.Name = "checkBoxClass0";
            this.checkBoxClass0.Size = new System.Drawing.Size(60, 17);
            this.checkBoxClass0.TabIndex = 0;
            this.checkBoxClass0.Text = "Class 0";
            this.checkBoxClass0.UseVisualStyleBackColor = true;
            // 
            // checkBoxClass1
            // 
            this.checkBoxClass1.AutoSize = true;
            this.checkBoxClass1.Location = new System.Drawing.Point(11, 36);
            this.checkBoxClass1.Name = "checkBoxClass1";
            this.checkBoxClass1.Size = new System.Drawing.Size(60, 17);
            this.checkBoxClass1.TabIndex = 1;
            this.checkBoxClass1.Text = "Class 1";
            this.checkBoxClass1.UseVisualStyleBackColor = true;
            // 
            // checkBoxClass2
            // 
            this.checkBoxClass2.AutoSize = true;
            this.checkBoxClass2.Location = new System.Drawing.Point(11, 59);
            this.checkBoxClass2.Name = "checkBoxClass2";
            this.checkBoxClass2.Size = new System.Drawing.Size(60, 17);
            this.checkBoxClass2.TabIndex = 2;
            this.checkBoxClass2.Text = "Class 2";
            this.checkBoxClass2.UseVisualStyleBackColor = true;
            // 
            // checkBoxClass3
            // 
            this.checkBoxClass3.AutoSize = true;
            this.checkBoxClass3.Location = new System.Drawing.Point(11, 82);
            this.checkBoxClass3.Name = "checkBoxClass3";
            this.checkBoxClass3.Size = new System.Drawing.Size(60, 17);
            this.checkBoxClass3.TabIndex = 3;
            this.checkBoxClass3.Text = "Class 3";
            this.checkBoxClass3.UseVisualStyleBackColor = true;
            // 
            // ClassFieldControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.checkBoxClass3);
            this.Controls.Add(this.checkBoxClass2);
            this.Controls.Add(this.checkBoxClass1);
            this.Controls.Add(this.checkBoxClass0);
            this.Name = "ClassFieldControl";
            this.Size = new System.Drawing.Size(77, 112);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBoxClass0;
        private System.Windows.Forms.CheckBox checkBoxClass1;
        private System.Windows.Forms.CheckBox checkBoxClass2;
        private System.Windows.Forms.CheckBox checkBoxClass3;
    }
}
