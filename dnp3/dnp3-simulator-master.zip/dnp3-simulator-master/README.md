### Graphical DNP3 Master/Outstation simulator

Depends on opendnp3 via NuGet:

[https://www.nuget.org/packages/opendnp3](https://www.nuget.org/packages/opendnp3)